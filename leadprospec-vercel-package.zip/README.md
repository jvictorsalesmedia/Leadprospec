# Leadprospec

Site estático pronto para Vercel.

O front-end é hospedado pela Vercel e usa a API/banco já publicados no Supabase:

`https://rhzayzebnmiuweffobzn.supabase.co/functions/v1/cartao-leads`

## Logins

- Breno: `breno.portes` / `gestao147`
- Amanda: `amanda` / `Amandacdt@`
- Giovana: `giovana` / `Giovana@cdt.`
